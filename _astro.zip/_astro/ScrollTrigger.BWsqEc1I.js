function mi(o, e) {
    for (var n = 0; n < e.length; n++) {
        var t = e[n];
        t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(o, t.key, t)
    }
}

function xi(o, e, n) {
    return e && mi(o.prototype, e), o
}
/*!
 * Observer 3.13.0
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */
var ve, Gr, Ve, Dt, Rt, nr, qn, Bt, mr, Kn, wt, ot, Zn, Jn = function() {
        return ve || typeof window < "u" && (ve = window.gsap) && ve.registerPlugin && ve
    },
    Qn = 1,
    rr = [],
    P = [],
    ft = [],
    xr = Date.now,
    fn = function(e, n) {
        return n
    },
    wi = function() {
        var e = mr.core,
            n = e.bridge || {},
            t = e._scrollers,
            r = e._proxies;
        t.push.apply(t, P), r.push.apply(r, ft), P = t, ft = r, fn = function(u, l) {
            return n[u](l)
        }
    },
    At = function(e, n) {
        return ~ft.indexOf(e) && ft[ft.indexOf(e) + 1][n]
    },
    wr = function(e) {
        return !!~Kn.indexOf(e)
    },
    Ae = function(e, n, t, r, i) {
        return e.addEventListener(n, t, {
            passive: r !== !1,
            capture: !!i
        })
    },
    Re = function(e, n, t, r) {
        return e.removeEventListener(n, t, !!r)
    },
    Ar = "scrollLeft",
    Or = "scrollTop",
    pn = function() {
        return wt && wt.isPressed || P.cache++
    },
    Zr = function(e, n) {
        var t = function r(i) {
            if (i || i === 0) {
                Qn && (Ve.history.scrollRestoration = "manual");
                var u = wt && wt.isPressed;
                i = r.v = Math.round(i) || (wt && wt.iOS ? 1 : 0), e(i), r.cacheID = P.cache, u && fn("ss", i)
            } else(n || P.cache !== r.cacheID || fn("ref")) && (r.cacheID = P.cache, r.v = e());
            return r.v + r.offset
        };
        return t.offset = 0, e && t
    },
    Le = {
        s: Ar,
        p: "left",
        p2: "Left",
        os: "right",
        os2: "Right",
        d: "width",
        d2: "Width",
        a: "x",
        sc: Zr(function(o) {
            return arguments.length ? Ve.scrollTo(o, ae.sc()) : Ve.pageXOffset || Dt[Ar] || Rt[Ar] || nr[Ar] || 0
        })
    },
    ae = {
        s: Or,
        p: "top",
        p2: "Top",
        os: "bottom",
        os2: "Bottom",
        d: "height",
        d2: "Height",
        a: "y",
        op: Le,
        sc: Zr(function(o) {
            return arguments.length ? Ve.scrollTo(Le.sc(), o) : Ve.pageYOffset || Dt[Or] || Rt[Or] || nr[Or] || 0
        })
    },
    Be = function(e, n) {
        return (n && n._ctx && n._ctx.selector || ve.utils.toArray)(e)[0] || (typeof e == "string" && ve.config().nullTargetWarn !== !1 ? console.warn("Element not found:", e) : null)
    },
    yi = function(e, n) {
        for (var t = n.length; t--;)
            if (n[t] === e || n[t].contains(e)) return !0;
        return !1
    },
    Ot = function(e, n) {
        var t = n.s,
            r = n.sc;
        wr(e) && (e = Dt.scrollingElement || Rt);
        var i = P.indexOf(e),
            u = r === ae.sc ? 1 : 2;
        !~i && (i = P.push(e) - 1), P[i + u] || Ae(e, "scroll", pn);
        var l = P[i + u],
            p = l || (P[i + u] = Zr(At(e, t), !0) || (wr(e) ? r : Zr(function(x) {
                return arguments.length ? e[t] = x : e[t]
            })));
        return p.target = e, l || (p.smooth = ve.getProperty(e, "scrollBehavior") === "smooth"), p
    },
    dn = function(e, n, t) {
        var r = e,
            i = e,
            u = xr(),
            l = u,
            p = n || 50,
            x = Math.max(500, p * 3),
            Y = function(v, $) {
                var X = xr();
                $ || X - u > p ? (i = r, r = v, l = u, u = X) : t ? r += v : r = i + (v - i) / (X - l) * (u - l)
            },
            M = function() {
                i = r = t ? 0 : r, l = u = 0
            },
            h = function(v) {
                var $ = l,
                    X = i,
                    ne = xr();
                return (v || v === 0) && v !== r && Y(v), u === l || ne - l > x ? 0 : (r + (t ? X : -X)) / ((t ? ne : u) - $) * 1e3
            };
        return {
            update: Y,
            reset: M,
            getVelocity: h
        }
    },
    fr = function(e, n) {
        return n && !e._gsapAllow && e.preventDefault(), e.changedTouches ? e.changedTouches[0] : e
    },
    Dn = function(e) {
        var n = Math.max.apply(Math, e),
            t = Math.min.apply(Math, e);
        return Math.abs(n) >= Math.abs(t) ? n : t
    },
    jn = function() {
        mr = ve.core.globals().ScrollTrigger, mr && mr.core && wi()
    },
    ei = function(e) {
        return ve = e || Jn(), !Gr && ve && typeof document < "u" && document.body && (Ve = window, Dt = document, Rt = Dt.documentElement, nr = Dt.body, Kn = [Ve, Dt, Rt, nr], ve.utils.clamp, Zn = ve.core.context || function() {}, Bt = "onpointerenter" in nr ? "pointer" : "mouse", qn = J.isTouch = Ve.matchMedia && Ve.matchMedia("(hover: none), (pointer: coarse)").matches ? 1 : "ontouchstart" in Ve || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? 2 : 0, ot = J.eventTypes = ("ontouchstart" in Rt ? "touchstart,touchmove,touchcancel,touchend" : "onpointerdown" in Rt ? "pointerdown,pointermove,pointercancel,pointerup" : "mousedown,mousemove,mouseup,mouseup").split(","), setTimeout(function() {
            return Qn = 0
        }, 500), jn(), Gr = 1), Gr
    };
Le.op = ae;
P.cache = 0;
var J = (function() {
    function o(n) {
        this.init(n)
    }
    var e = o.prototype;
    return e.init = function(t) {
        Gr || ei(ve) || console.warn("Please gsap.registerPlugin(Observer)"), mr || jn();
        var r = t.tolerance,
            i = t.dragMinimum,
            u = t.type,
            l = t.target,
            p = t.lineHeight,
            x = t.debounce,
            Y = t.preventDefault,
            M = t.onStop,
            h = t.onStopDelay,
            c = t.ignore,
            v = t.wheelSpeed,
            $ = t.event,
            X = t.onDragStart,
            ne = t.onDragEnd,
            W = t.onDrag,
            ge = t.onPress,
            k = t.onRelease,
            qe = t.onRight,
            N = t.onLeft,
            y = t.onUp,
            Te = t.onDown,
            Ie = t.onChangeX,
            g = t.onChangeY,
            ue = t.onChange,
            w = t.onToggleX,
            pt = t.onToggleY,
            ie = t.onHover,
            Ee = t.onHoverEnd,
            Pe = t.onMove,
            I = t.ignoreCheck,
            Q = t.isNormalizer,
            j = t.onGestureStart,
            s = t.onGestureEnd,
            oe = t.onWheel,
            Yt = t.onEnable,
            bt = t.onDisable,
            Ke = t.onClick,
            dt = t.scrollSpeed,
            me = t.capture,
            ee = t.allowClicks,
            Me = t.lockAxis,
            xe = t.onLockAxis;
        this.target = l = Be(l) || Rt, this.vars = t, c && (c = ve.utils.toArray(c)), r = r || 1e-9, i = i || 0, v = v || 1, dt = dt || 1, u = u || "wheel,touch,pointer", x = x !== !1, p || (p = parseFloat(Ve.getComputedStyle(nr).lineHeight) || 22);
        var Ct, De, ze, O, q, Xe, Ne, a = this,
            He = 0,
            gt = 0,
            St = t.passive || !Y && t.passive !== !1,
            U = Ot(l, Le),
            ht = Ot(l, ae),
            kt = U(),
            Ft = ht(),
            ce = ~u.indexOf("touch") && !~u.indexOf("pointer") && ot[0] === "pointerdown",
            Tt = wr(l),
            K = l.ownerDocument || Dt,
            et = [0, 0, 0],
            Ze = [0, 0, 0],
            _t = 0,
            lr = function() {
                return _t = xr()
            },
            te = function(m, F) {
                return (a.event = m) && c && yi(m.target, c) || F && ce && m.pointerType !== "touch" || I && I(m, F)
            },
            Mr = function() {
                a._vx.reset(), a._vy.reset(), De.pause(), M && M(a)
            },
            vt = function() {
                var m = a.deltaX = Dn(et),
                    F = a.deltaY = Dn(Ze),
                    f = Math.abs(m) >= r,
                    b = Math.abs(F) >= r;
                ue && (f || b) && ue(a, m, F, et, Ze), f && (qe && a.deltaX > 0 && qe(a), N && a.deltaX < 0 && N(a), Ie && Ie(a), w && a.deltaX < 0 != He < 0 && w(a), He = a.deltaX, et[0] = et[1] = et[2] = 0), b && (Te && a.deltaY > 0 && Te(a), y && a.deltaY < 0 && y(a), g && g(a), pt && a.deltaY < 0 != gt < 0 && pt(a), gt = a.deltaY, Ze[0] = Ze[1] = Ze[2] = 0), (O || ze) && (Pe && Pe(a), ze && (X && ze === 1 && X(a), W && W(a), ze = 0), O = !1), Xe && !(Xe = !1) && xe && xe(a), q && (oe(a), q = !1), Ct = 0
            },
            Kt = function(m, F, f) {
                et[f] += m, Ze[f] += F, a._vx.update(m), a._vy.update(F), x ? Ct || (Ct = requestAnimationFrame(vt)) : vt()
            },
            Zt = function(m, F) {
                Me && !Ne && (a.axis = Ne = Math.abs(m) > Math.abs(F) ? "x" : "y", Xe = !0), Ne !== "y" && (et[2] += m, a._vx.update(m, !0)), Ne !== "x" && (Ze[2] += F, a._vy.update(F, !0)), x ? Ct || (Ct = requestAnimationFrame(vt)) : vt()
            },
            Et = function(m) {
                if (!te(m, 1)) {
                    m = fr(m, Y);
                    var F = m.clientX,
                        f = m.clientY,
                        b = F - a.x,
                        _ = f - a.y,
                        C = a.isDragging;
                    a.x = F, a.y = f, (C || (b || _) && (Math.abs(a.startX - F) >= i || Math.abs(a.startY - f) >= i)) && (ze = C ? 2 : 1, C || (a.isDragging = !0), Zt(b, _))
                }
            },
            Lt = a.onPress = function(S) {
                te(S, 1) || S && S.button || (a.axis = Ne = null, De.pause(), a.isPressed = !0, S = fr(S), He = gt = 0, a.startX = a.x = S.clientX, a.startY = a.y = S.clientY, a._vx.reset(), a._vy.reset(), Ae(Q ? l : K, ot[1], Et, St, !0), a.deltaX = a.deltaY = 0, ge && ge(a))
            },
            D = a.onRelease = function(S) {
                if (!te(S, 1)) {
                    Re(Q ? l : K, ot[1], Et, !0);
                    var m = !isNaN(a.y - a.startY),
                        F = a.isDragging,
                        f = F && (Math.abs(a.x - a.startX) > 3 || Math.abs(a.y - a.startY) > 3),
                        b = fr(S);
                    !f && m && (a._vx.reset(), a._vy.reset(), Y && ee && ve.delayedCall(.08, function() {
                        if (xr() - _t > 300 && !S.defaultPrevented) {
                            if (S.target.click) S.target.click();
                            else if (K.createEvent) {
                                var _ = K.createEvent("MouseEvents");
                                _.initMouseEvent("click", !0, !0, Ve, 1, b.screenX, b.screenY, b.clientX, b.clientY, !1, !1, !1, !1, 0, null), S.target.dispatchEvent(_)
                            }
                        }
                    })), a.isDragging = a.isGesturing = a.isPressed = !1, M && F && !Q && De.restart(!0), ze && vt(), ne && F && ne(a), k && k(a, f)
                }
            },
            It = function(m) {
                return m.touches && m.touches.length > 1 && (a.isGesturing = !0) && j(m, a.isDragging)
            },
            tt = function() {
                return (a.isGesturing = !1) || s(a)
            },
            rt = function(m) {
                if (!te(m)) {
                    var F = U(),
                        f = ht();
                    Kt((F - kt) * dt, (f - Ft) * dt, 1), kt = F, Ft = f, M && De.restart(!0)
                }
            },
            nt = function(m) {
                if (!te(m)) {
                    m = fr(m, Y), oe && (q = !0);
                    var F = (m.deltaMode === 1 ? p : m.deltaMode === 2 ? Ve.innerHeight : 1) * v;
                    Kt(m.deltaX * F, m.deltaY * F, 0), M && !Q && De.restart(!0)
                }
            },
            zt = function(m) {
                if (!te(m)) {
                    var F = m.clientX,
                        f = m.clientY,
                        b = F - a.x,
                        _ = f - a.y;
                    a.x = F, a.y = f, O = !0, M && De.restart(!0), (b || _) && Zt(b, _)
                }
            },
            Jt = function(m) {
                a.event = m, ie(a)
            },
            mt = function(m) {
                a.event = m, Ee(a)
            },
            ar = function(m) {
                return te(m) || fr(m, Y) && Ke(a)
            };
        De = a._dc = ve.delayedCall(h || .25, Mr).pause(), a.deltaX = a.deltaY = 0, a._vx = dn(0, 50, !0), a._vy = dn(0, 50, !0), a.scrollX = U, a.scrollY = ht, a.isDragging = a.isGesturing = a.isPressed = !1, Zn(this), a.enable = function(S) {
            return a.isEnabled || (Ae(Tt ? K : l, "scroll", pn), u.indexOf("scroll") >= 0 && Ae(Tt ? K : l, "scroll", rt, St, me), u.indexOf("wheel") >= 0 && Ae(l, "wheel", nt, St, me), (u.indexOf("touch") >= 0 && qn || u.indexOf("pointer") >= 0) && (Ae(l, ot[0], Lt, St, me), Ae(K, ot[2], D), Ae(K, ot[3], D), ee && Ae(l, "click", lr, !0, !0), Ke && Ae(l, "click", ar), j && Ae(K, "gesturestart", It), s && Ae(K, "gestureend", tt), ie && Ae(l, Bt + "enter", Jt), Ee && Ae(l, Bt + "leave", mt), Pe && Ae(l, Bt + "move", zt)), a.isEnabled = !0, a.isDragging = a.isGesturing = a.isPressed = O = ze = !1, a._vx.reset(), a._vy.reset(), kt = U(), Ft = ht(), S && S.type && Lt(S), Yt && Yt(a)), a
        }, a.disable = function() {
            a.isEnabled && (rr.filter(function(S) {
                return S !== a && wr(S.target)
            }).length || Re(Tt ? K : l, "scroll", pn), a.isPressed && (a._vx.reset(), a._vy.reset(), Re(Q ? l : K, ot[1], Et, !0)), Re(Tt ? K : l, "scroll", rt, me), Re(l, "wheel", nt, me), Re(l, ot[0], Lt, me), Re(K, ot[2], D), Re(K, ot[3], D), Re(l, "click", lr, !0), Re(l, "click", ar), Re(K, "gesturestart", It), Re(K, "gestureend", tt), Re(l, Bt + "enter", Jt), Re(l, Bt + "leave", mt), Re(l, Bt + "move", zt), a.isEnabled = a.isPressed = a.isDragging = !1, bt && bt(a))
        }, a.kill = a.revert = function() {
            a.disable();
            var S = rr.indexOf(a);
            S >= 0 && rr.splice(S, 1), wt === a && (wt = 0)
        }, rr.push(a), Q && wr(l) && (wt = a), a.enable($)
    }, xi(o, [{
        key: "velocityX",
        get: function() {
            return this._vx.getVelocity()
        }
    }, {
        key: "velocityY",
        get: function() {
            return this._vy.getVelocity()
        }
    }]), o
})();
J.version = "3.13.0";
J.create = function(o) {
    return new J(o)
};
J.register = ei;
J.getAll = function() {
    return rr.slice()
};
J.getById = function(o) {
    return rr.filter(function(e) {
        return e.vars.id === o
    })[0]
};
Jn() && ve.registerPlugin(J);
/*!
 * ScrollTrigger 3.13.0
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */
var d, er, E, B, Ue, L, yn, Jr, Er, yr, dr, Yr, Ce, tn, gn, Ye, Rn, An, tr, ti, nn, ri, Oe, hn, ni, ii, Mt, _n, bn, ir, Cn, Qr, vn, on, Fr = 1,
    Se = Date.now,
    sn = Se(),
    je = 0,
    gr = 0,
    On = function(e, n, t) {
        var r = $e(e) && (e.substr(0, 6) === "clamp(" || e.indexOf("max") > -1);
        return t["_" + n + "Clamp"] = r, r ? e.substr(6, e.length - 7) : e
    },
    Yn = function(e, n) {
        return n && (!$e(e) || e.substr(0, 6) !== "clamp(") ? "clamp(" + e + ")" : e
    },
    bi = function o() {
        return gr && requestAnimationFrame(o)
    },
    Fn = function() {
        return tn = 1
    },
    Ln = function() {
        return tn = 0
    },
    ut = function(e) {
        return e
    },
    hr = function(e) {
        return Math.round(e * 1e5) / 1e5 || 0
    },
    oi = function() {
        return typeof window < "u"
    },
    si = function() {
        return d || oi() && (d = window.gsap) && d.registerPlugin && d
    },
    Ut = function(e) {
        return !!~yn.indexOf(e)
    },
    li = function(e) {
        return (e === "Height" ? Cn : E["inner" + e]) || Ue["client" + e] || L["client" + e]
    },
    ai = function(e) {
        return At(e, "getBoundingClientRect") || (Ut(e) ? function() {
            return Kr.width = E.innerWidth, Kr.height = Cn, Kr
        } : function() {
            return xt(e)
        })
    },
    Ci = function(e, n, t) {
        var r = t.d,
            i = t.d2,
            u = t.a;
        return (u = At(e, "getBoundingClientRect")) ? function() {
            return u()[r]
        } : function() {
            return (n ? li(i) : e["client" + i]) || 0
        }
    },
    Si = function(e, n) {
        return !n || ~ft.indexOf(e) ? ai(e) : function() {
            return Kr
        }
    },
    ct = function(e, n) {
        var t = n.s,
            r = n.d2,
            i = n.d,
            u = n.a;
        return Math.max(0, (t = "scroll" + r) && (u = At(e, t)) ? u() - ai(e)()[i] : Ut(e) ? (Ue[t] || L[t]) - li(r) : e[t] - e["offset" + r])
    },
    Lr = function(e, n) {
        for (var t = 0; t < tr.length; t += 3)(!n || ~n.indexOf(tr[t + 1])) && e(tr[t], tr[t + 1], tr[t + 2])
    },
    $e = function(e) {
        return typeof e == "string"
    },
    ke = function(e) {
        return typeof e == "function"
    },
    _r = function(e) {
        return typeof e == "number"
    },
    Nt = function(e) {
        return typeof e == "object"
    },
    pr = function(e, n, t) {
        return e && e.progress(n ? 0 : 1) && t && e.pause()
    },
    ln = function(e, n) {
        if (e.enabled) {
            var t = e._ctx ? e._ctx.add(function() {
                return n(e)
            }) : n(e);
            t && t.totalTime && (e.callbackAnimation = t)
        }
    },
    Qt = Math.abs,
    ui = "left",
    ci = "top",
    Sn = "right",
    kn = "bottom",
    Wt = "width",
    Gt = "height",
    br = "Right",
    Cr = "Left",
    Sr = "Top",
    kr = "Bottom",
    re = "padding",
    Je = "margin",
    sr = "Width",
    Tn = "Height",
    le = "px",
    Qe = function(e) {
        return E.getComputedStyle(e)
    },
    ki = function(e) {
        var n = Qe(e).position;
        e.style.position = n === "absolute" || n === "fixed" ? n : "relative"
    },
    In = function(e, n) {
        for (var t in n) t in e || (e[t] = n[t]);
        return e
    },
    xt = function(e, n) {
        var t = n && Qe(e)[gn] !== "matrix(1, 0, 0, 1, 0, 0)" && d.to(e, {
                x: 0,
                y: 0,
                xPercent: 0,
                yPercent: 0,
                rotation: 0,
                rotationX: 0,
                rotationY: 0,
                scale: 1,
                skewX: 0,
                skewY: 0
            }).progress(1),
            r = e.getBoundingClientRect();
        return t && t.progress(0).kill(), r
    },
    jr = function(e, n) {
        var t = n.d2;
        return e["offset" + t] || e["client" + t] || 0
    },
    fi = function(e) {
        var n = [],
            t = e.labels,
            r = e.duration(),
            i;
        for (i in t) n.push(t[i] / r);
        return n
    },
    Ti = function(e) {
        return function(n) {
            return d.utils.snap(fi(e), n)
        }
    },
    En = function(e) {
        var n = d.utils.snap(e),
            t = Array.isArray(e) && e.slice(0).sort(function(r, i) {
                return r - i
            });
        return t ? function(r, i, u) {
            u === void 0 && (u = .001);
            var l;
            if (!i) return n(r);
            if (i > 0) {
                for (r -= u, l = 0; l < t.length; l++)
                    if (t[l] >= r) return t[l];
                return t[l - 1]
            } else
                for (l = t.length, r += u; l--;)
                    if (t[l] <= r) return t[l];
            return t[0]
        } : function(r, i, u) {
            u === void 0 && (u = .001);
            var l = n(r);
            return !i || Math.abs(l - r) < u || l - r < 0 == i < 0 ? l : n(i < 0 ? r - e : r + e)
        }
    },
    Ei = function(e) {
        return function(n, t) {
            return En(fi(e))(n, t.direction)
        }
    },
    Ir = function(e, n, t, r) {
        return t.split(",").forEach(function(i) {
            return e(n, i, r)
        })
    },
    de = function(e, n, t, r, i) {
        return e.addEventListener(n, t, {
            passive: !r,
            capture: !!i
        })
    },
    pe = function(e, n, t, r) {
        return e.removeEventListener(n, t, !!r)
    },
    zr = function(e, n, t) {
        t = t && t.wheelHandler, t && (e(n, "wheel", t), e(n, "touchmove", t))
    },
    zn = {
        startColor: "green",
        endColor: "red",
        indent: 0,
        fontSize: "16px",
        fontWeight: "normal"
    },
    Xr = {
        toggleActions: "play",
        anticipatePin: 0
    },
    en = {
        top: 0,
        left: 0,
        center: .5,
        bottom: 1,
        right: 1
    },
    $r = function(e, n) {
        if ($e(e)) {
            var t = e.indexOf("="),
                r = ~t ? +(e.charAt(t - 1) + 1) * parseFloat(e.substr(t + 1)) : 0;
            ~t && (e.indexOf("%") > t && (r *= n / 100), e = e.substr(0, t - 1)), e = r + (e in en ? en[e] * n : ~e.indexOf("%") ? parseFloat(e) * n / 100 : parseFloat(e) || 0)
        }
        return e
    },
    Br = function(e, n, t, r, i, u, l, p) {
        var x = i.startColor,
            Y = i.endColor,
            M = i.fontSize,
            h = i.indent,
            c = i.fontWeight,
            v = B.createElement("div"),
            $ = Ut(t) || At(t, "pinType") === "fixed",
            X = e.indexOf("scroller") !== -1,
            ne = $ ? L : t,
            W = e.indexOf("start") !== -1,
            ge = W ? x : Y,
            k = "border-color:" + ge + ";font-size:" + M + ";color:" + ge + ";font-weight:" + c + ";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";
        return k += "position:" + ((X || p) && $ ? "fixed;" : "absolute;"), (X || p || !$) && (k += (r === ae ? Sn : kn) + ":" + (u + parseFloat(h)) + "px;"), l && (k += "box-sizing:border-box;text-align:left;width:" + l.offsetWidth + "px;"), v._isStart = W, v.setAttribute("class", "gsap-marker-" + e + (n ? " marker-" + n : "")), v.style.cssText = k, v.innerText = n || n === 0 ? e + "-" + n : e, ne.children[0] ? ne.insertBefore(v, ne.children[0]) : ne.appendChild(v), v._offset = v["offset" + r.op.d2], Ur(v, 0, r, W), v
    },
    Ur = function(e, n, t, r) {
        var i = {
                display: "block"
            },
            u = t[r ? "os2" : "p2"],
            l = t[r ? "p2" : "os2"];
        e._isFlipped = r, i[t.a + "Percent"] = r ? -100 : 0, i[t.a] = r ? "1px" : 0, i["border" + u + sr] = 1, i["border" + l + sr] = 0, i[t.p] = n + "px", d.set(e, i)
    },
    T = [],
    mn = {},
    Pr, Xn = function() {
        return Se() - je > 34 && (Pr || (Pr = requestAnimationFrame(yt)))
    },
    jt = function() {
        (!Oe || !Oe.isPressed || Oe.startX > L.clientWidth) && (P.cache++, Oe ? Pr || (Pr = requestAnimationFrame(yt)) : yt(), je || qt("scrollStart"), je = Se())
    },
    an = function() {
        ii = E.innerWidth, ni = E.innerHeight
    },
    vr = function(e) {
        P.cache++, (e === !0 || !Ce && !ri && !B.fullscreenElement && !B.webkitFullscreenElement && (!hn || ii !== E.innerWidth || Math.abs(E.innerHeight - ni) > E.innerHeight * .25)) && Jr.restart(!0)
    },
    Vt = {},
    Pi = [],
    pi = function o() {
        return pe(R, "scrollEnd", o) || Ht(!0)
    },
    qt = function(e) {
        return Vt[e] && Vt[e].map(function(n) {
            return n()
        }) || Pi
    },
    Ge = [],
    di = function(e) {
        for (var n = 0; n < Ge.length; n += 5)(!e || Ge[n + 4] && Ge[n + 4].query === e) && (Ge[n].style.cssText = Ge[n + 1], Ge[n].getBBox && Ge[n].setAttribute("transform", Ge[n + 2] || ""), Ge[n + 3].uncache = 1)
    },
    Pn = function(e, n) {
        var t;
        for (Ye = 0; Ye < T.length; Ye++) t = T[Ye], t && (!n || t._ctx === n) && (e ? t.kill(1) : t.revert(!0, !0));
        Qr = !0, n && di(n), n || qt("revert")
    },
    gi = function(e, n) {
        P.cache++, (n || !Fe) && P.forEach(function(t) {
            return ke(t) && t.cacheID++ && (t.rec = 0)
        }), $e(e) && (E.history.scrollRestoration = bn = e)
    },
    Fe, $t = 0,
    Bn, Mi = function() {
        if (Bn !== $t) {
            var e = Bn = $t;
            requestAnimationFrame(function() {
                return e === $t && Ht(!0)
            })
        }
    },
    hi = function() {
        L.appendChild(ir), Cn = !Oe && ir.offsetHeight || E.innerHeight, L.removeChild(ir)
    },
    Nn = function(e) {
        return Er(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(n) {
            return n.style.display = e ? "none" : "block"
        })
    },
    Ht = function(e, n) {
        if (Ue = B.documentElement, L = B.body, yn = [E, B, Ue, L], je && !e && !Qr) {
            de(R, "scrollEnd", pi);
            return
        }
        hi(), Fe = R.isRefreshing = !0, P.forEach(function(r) {
            return ke(r) && ++r.cacheID && (r.rec = r())
        });
        var t = qt("refreshInit");
        ti && R.sort(), n || Pn(), P.forEach(function(r) {
            ke(r) && (r.smooth && (r.target.style.scrollBehavior = "auto"), r(0))
        }), T.slice(0).forEach(function(r) {
            return r.refresh()
        }), Qr = !1, T.forEach(function(r) {
            if (r._subPinOffset && r.pin) {
                var i = r.vars.horizontal ? "offsetWidth" : "offsetHeight",
                    u = r.pin[i];
                r.revert(!0, 1), r.adjustPinSpacing(r.pin[i] - u), r.refresh()
            }
        }), vn = 1, Nn(!0), T.forEach(function(r) {
            var i = ct(r.scroller, r._dir),
                u = r.vars.end === "max" || r._endClamp && r.end > i,
                l = r._startClamp && r.start >= i;
            (u || l) && r.setPositions(l ? i - 1 : r.start, u ? Math.max(l ? i : r.start + 1, i) : r.end, !0)
        }), Nn(!1), vn = 0, t.forEach(function(r) {
            return r && r.render && r.render(-1)
        }), P.forEach(function(r) {
            ke(r) && (r.smooth && requestAnimationFrame(function() {
                return r.target.style.scrollBehavior = "smooth"
            }), r.rec && r(r.rec))
        }), gi(bn, 1), Jr.pause(), $t++, Fe = 2, yt(2), T.forEach(function(r) {
            return ke(r.vars.onRefresh) && r.vars.onRefresh(r)
        }), Fe = R.isRefreshing = !1, qt("refresh")
    },
    xn = 0,
    Vr = 1,
    Tr, yt = function(e) {
        if (e === 2 || !Fe && !Qr) {
            R.isUpdating = !0, Tr && Tr.update(0);
            var n = T.length,
                t = Se(),
                r = t - sn >= 50,
                i = n && T[0].scroll();
            if (Vr = xn > i ? -1 : 1, Fe || (xn = i), r && (je && !tn && t - je > 200 && (je = 0, qt("scrollEnd")), dr = sn, sn = t), Vr < 0) {
                for (Ye = n; Ye-- > 0;) T[Ye] && T[Ye].update(0, r);
                Vr = 1
            } else
                for (Ye = 0; Ye < n; Ye++) T[Ye] && T[Ye].update(0, r);
            R.isUpdating = !1
        }
        Pr = 0
    },
    wn = [ui, ci, kn, Sn, Je + kr, Je + br, Je + Sr, Je + Cr, "display", "flexShrink", "float", "zIndex", "gridColumnStart", "gridColumnEnd", "gridRowStart", "gridRowEnd", "gridArea", "justifySelf", "alignSelf", "placeSelf", "order"],
    qr = wn.concat([Wt, Gt, "boxSizing", "max" + sr, "max" + Tn, "position", Je, re, re + Sr, re + br, re + kr, re + Cr]),
    Di = function(e, n, t) {
        or(t);
        var r = e._gsap;
        if (r.spacerIsNative) or(r.spacerState);
        else if (e._gsap.swappedIn) {
            var i = n.parentNode;
            i && (i.insertBefore(e, n), i.removeChild(n))
        }
        e._gsap.swappedIn = !1
    },
    un = function(e, n, t, r) {
        if (!e._gsap.swappedIn) {
            for (var i = wn.length, u = n.style, l = e.style, p; i--;) p = wn[i], u[p] = t[p];
            u.position = t.position === "absolute" ? "absolute" : "relative", t.display === "inline" && (u.display = "inline-block"), l[kn] = l[Sn] = "auto", u.flexBasis = t.flexBasis || "auto", u.overflow = "visible", u.boxSizing = "border-box", u[Wt] = jr(e, Le) + le, u[Gt] = jr(e, ae) + le, u[re] = l[Je] = l[ci] = l[ui] = "0", or(r), l[Wt] = l["max" + sr] = t[Wt], l[Gt] = l["max" + Tn] = t[Gt], l[re] = t[re], e.parentNode !== n && (e.parentNode.insertBefore(n, e), n.appendChild(e)), e._gsap.swappedIn = !0
        }
    },
    Ri = /([A-Z])/g,
    or = function(e) {
        if (e) {
            var n = e.t.style,
                t = e.length,
                r = 0,
                i, u;
            for ((e.t._gsap || d.core.getCache(e.t)).uncache = 1; r < t; r += 2) u = e[r + 1], i = e[r], u ? n[i] = u : n[i] && n.removeProperty(i.replace(Ri, "-$1").toLowerCase())
        }
    },
    Nr = function(e) {
        for (var n = qr.length, t = e.style, r = [], i = 0; i < n; i++) r.push(qr[i], t[qr[i]]);
        return r.t = e, r
    },
    Ai = function(e, n, t) {
        for (var r = [], i = e.length, u = t ? 8 : 0, l; u < i; u += 2) l = e[u], r.push(l, l in n ? n[l] : e[u + 1]);
        return r.t = e.t, r
    },
    Kr = {
        left: 0,
        top: 0
    },
    Hn = function(e, n, t, r, i, u, l, p, x, Y, M, h, c, v) {
        ke(e) && (e = e(p)), $e(e) && e.substr(0, 3) === "max" && (e = h + (e.charAt(4) === "=" ? $r("0" + e.substr(3), t) : 0));
        var $ = c ? c.time() : 0,
            X, ne, W;
        if (c && c.seek(0), isNaN(e) || (e = +e), _r(e)) c && (e = d.utils.mapRange(c.scrollTrigger.start, c.scrollTrigger.end, 0, h, e)), l && Ur(l, t, r, !0);
        else {
            ke(n) && (n = n(p));
            var ge = (e || "0").split(" "),
                k, qe, N, y;
            W = Be(n, p) || L, k = xt(W) || {}, (!k || !k.left && !k.top) && Qe(W).display === "none" && (y = W.style.display, W.style.display = "block", k = xt(W), y ? W.style.display = y : W.style.removeProperty("display")), qe = $r(ge[0], k[r.d]), N = $r(ge[1] || "0", t), e = k[r.p] - x[r.p] - Y + qe + i - N, l && Ur(l, N, r, t - N < 20 || l._isStart && N > 20), t -= t - N
        }
        if (v && (p[v] = e || -.001, e < 0 && (e = 0)), u) {
            var Te = e + t,
                Ie = u._isStart;
            X = "scroll" + r.d2, Ur(u, Te, r, Ie && Te > 20 || !Ie && (M ? Math.max(L[X], Ue[X]) : u.parentNode[X]) <= Te + 1), M && (x = xt(l), M && (u.style[r.op.p] = x[r.op.p] - r.op.m - u._offset + le))
        }
        return c && W && (X = xt(W), c.seek(h), ne = xt(W), c._caScrollDist = X[r.p] - ne[r.p], e = e / c._caScrollDist * h), c && c.seek($), c ? e : Math.round(e)
    },
    Oi = /(webkit|moz|length|cssText|inset)/i,
    Wn = function(e, n, t, r) {
        if (e.parentNode !== n) {
            var i = e.style,
                u, l;
            if (n === L) {
                e._stOrig = i.cssText, l = Qe(e);
                for (u in l) !+u && !Oi.test(u) && l[u] && typeof i[u] == "string" && u !== "0" && (i[u] = l[u]);
                i.top = t, i.left = r
            } else i.cssText = e._stOrig;
            d.core.getCache(e).uncache = 1, n.appendChild(e)
        }
    },
    _i = function(e, n, t) {
        var r = n,
            i = r;
        return function(u) {
            var l = Math.round(e());
            return l !== r && l !== i && Math.abs(l - r) > 3 && Math.abs(l - i) > 3 && (u = l, t && t()), i = r, r = Math.round(u), r
        }
    },
    Hr = function(e, n, t) {
        var r = {};
        r[n.p] = "+=" + t, d.set(e, r)
    },
    Gn = function(e, n) {
        var t = Ot(e, n),
            r = "_scroll" + n.p2,
            i = function u(l, p, x, Y, M) {
                var h = u.tween,
                    c = p.onComplete,
                    v = {};
                x = x || t();
                var $ = _i(t, x, function() {
                    h.kill(), u.tween = 0
                });
                return M = Y && M || 0, Y = Y || l - x, h && h.kill(), p[r] = l, p.inherit = !1, p.modifiers = v, v[r] = function() {
                    return $(x + Y * h.ratio + M * h.ratio * h.ratio)
                }, p.onUpdate = function() {
                    P.cache++, u.tween && yt()
                }, p.onComplete = function() {
                    u.tween = 0, c && c.call(h)
                }, h = u.tween = d.to(e, p), h
            };
        return e[r] = t, t.wheelHandler = function() {
            return i.tween && i.tween.kill() && (i.tween = 0)
        }, de(e, "wheel", t.wheelHandler), R.isTouch && de(e, "touchmove", t.wheelHandler), i
    },
    R = (function() {
        function o(n, t) {
            er || o.register(d) || console.warn("Please gsap.registerPlugin(ScrollTrigger)"), _n(this), this.init(n, t)
        }
        var e = o.prototype;
        return e.init = function(t, r) {
            if (this.progress = this.start = 0, this.vars && this.kill(!0, !0), !gr) {
                this.update = this.refresh = this.kill = ut;
                return
            }
            t = In($e(t) || _r(t) || t.nodeType ? {
                trigger: t
            } : t, Xr);
            var i = t,
                u = i.onUpdate,
                l = i.toggleClass,
                p = i.id,
                x = i.onToggle,
                Y = i.onRefresh,
                M = i.scrub,
                h = i.trigger,
                c = i.pin,
                v = i.pinSpacing,
                $ = i.invalidateOnRefresh,
                X = i.anticipatePin,
                ne = i.onScrubComplete,
                W = i.onSnapComplete,
                ge = i.once,
                k = i.snap,
                qe = i.pinReparent,
                N = i.pinSpacer,
                y = i.containerAnimation,
                Te = i.fastScrollEnd,
                Ie = i.preventOverlaps,
                g = t.horizontal || t.containerAnimation && t.horizontal !== !1 ? Le : ae,
                ue = !M && M !== 0,
                w = Be(t.scroller || E),
                pt = d.core.getCache(w),
                ie = Ut(w),
                Ee = ("pinType" in t ? t.pinType : At(w, "pinType") || ie && "fixed") === "fixed",
                Pe = [t.onEnter, t.onLeave, t.onEnterBack, t.onLeaveBack],
                I = ue && t.toggleActions.split(" "),
                Q = "markers" in t ? t.markers : Xr.markers,
                j = ie ? 0 : parseFloat(Qe(w)["border" + g.p2 + sr]) || 0,
                s = this,
                oe = t.onRefreshInit && function() {
                    return t.onRefreshInit(s)
                },
                Yt = Ci(w, ie, g),
                bt = Si(w, ie),
                Ke = 0,
                dt = 0,
                me = 0,
                ee = Ot(w, g),
                Me, xe, Ct, De, ze, O, q, Xe, Ne, a, He, gt, St, U, ht, kt, Ft, ce, Tt, K, et, Ze, _t, lr, te, Mr, vt, Kt, Zt, Et, Lt, D, It, tt, rt, nt, zt, Jt, mt;
            if (s._startClamp = s._endClamp = !1, s._dir = g, X *= 45, s.scroller = w, s.scroll = y ? y.time.bind(y) : ee, De = ee(), s.vars = t, r = r || t.animation, "refreshPriority" in t && (ti = 1, t.refreshPriority === -9999 && (Tr = s)), pt.tweenScroll = pt.tweenScroll || {
                    top: Gn(w, ae),
                    left: Gn(w, Le)
                }, s.tweenTo = Me = pt.tweenScroll[g.p], s.scrubDuration = function(f) {
                    It = _r(f) && f, It ? D ? D.duration(f) : D = d.to(r, {
                        ease: "expo",
                        totalProgress: "+=0",
                        inherit: !1,
                        duration: It,
                        paused: !0,
                        onComplete: function() {
                            return ne && ne(s)
                        }
                    }) : (D && D.progress(1).kill(), D = 0)
                }, r && (r.vars.lazy = !1, r._initted && !s.isReverted || r.vars.immediateRender !== !1 && t.immediateRender !== !1 && r.duration() && r.render(0, !0, !0), s.animation = r.pause(), r.scrollTrigger = s, s.scrubDuration(M), Et = 0, p || (p = r.vars.id)), k && ((!Nt(k) || k.push) && (k = {
                    snapTo: k
                }), "scrollBehavior" in L.style && d.set(ie ? [L, Ue] : w, {
                    scrollBehavior: "auto"
                }), P.forEach(function(f) {
                    return ke(f) && f.target === (ie ? B.scrollingElement || Ue : w) && (f.smooth = !1)
                }), Ct = ke(k.snapTo) ? k.snapTo : k.snapTo === "labels" ? Ti(r) : k.snapTo === "labelsDirectional" ? Ei(r) : k.directional !== !1 ? function(f, b) {
                    return En(k.snapTo)(f, Se() - dt < 500 ? 0 : b.direction)
                } : d.utils.snap(k.snapTo), tt = k.duration || {
                    min: .1,
                    max: 2
                }, tt = Nt(tt) ? yr(tt.min, tt.max) : yr(tt, tt), rt = d.delayedCall(k.delay || It / 2 || .1, function() {
                    var f = ee(),
                        b = Se() - dt < 500,
                        _ = Me.tween;
                    if ((b || Math.abs(s.getVelocity()) < 10) && !_ && !tn && Ke !== f) {
                        var C = (f - O) / U,
                            fe = r && !ue ? r.totalProgress() : C,
                            A = b ? 0 : (fe - Lt) / (Se() - dr) * 1e3 || 0,
                            Z = d.utils.clamp(-C, 1 - C, Qt(A / 2) * A / .185),
                            we = C + (k.inertia === !1 ? 0 : Z),
                            V, H, z = k,
                            it = z.onStart,
                            G = z.onInterrupt,
                            We = z.onComplete;
                        if (V = Ct(we, s), _r(V) || (V = we), H = Math.max(0, Math.round(O + V * U)), f <= q && f >= O && H !== f) {
                            if (_ && !_._initted && _.data <= Qt(H - f)) return;
                            k.inertia === !1 && (Z = V - C), Me(H, {
                                duration: tt(Qt(Math.max(Qt(we - fe), Qt(V - fe)) * .185 / A / .05 || 0)),
                                ease: k.ease || "power3",
                                data: Qt(H - f),
                                onInterrupt: function() {
                                    return rt.restart(!0) && G && G(s)
                                },
                                onComplete: function() {
                                    s.update(), Ke = ee(), r && !ue && (D ? D.resetTo("totalProgress", V, r._tTime / r._tDur) : r.progress(V)), Et = Lt = r && !ue ? r.totalProgress() : s.progress, W && W(s), We && We(s)
                                }
                            }, f, Z * U, H - f - Z * U), it && it(s, Me.tween)
                        }
                    } else s.isActive && Ke !== f && rt.restart(!0)
                }).pause()), p && (mn[p] = s), h = s.trigger = Be(h || c !== !0 && c), mt = h && h._gsap && h._gsap.stRevert, mt && (mt = mt(s)), c = c === !0 ? h : Be(c), $e(l) && (l = {
                    targets: h,
                    className: l
                }), c && (v === !1 || v === Je || (v = !v && c.parentNode && c.parentNode.style && Qe(c.parentNode).display === "flex" ? !1 : re), s.pin = c, xe = d.core.getCache(c), xe.spacer ? ht = xe.pinState : (N && (N = Be(N), N && !N.nodeType && (N = N.current || N.nativeElement), xe.spacerIsNative = !!N, N && (xe.spacerState = Nr(N))), xe.spacer = ce = N || B.createElement("div"), ce.classList.add("pin-spacer"), p && ce.classList.add("pin-spacer-" + p), xe.pinState = ht = Nr(c)), t.force3D !== !1 && d.set(c, {
                    force3D: !0
                }), s.spacer = ce = xe.spacer, Zt = Qe(c), lr = Zt[v + g.os2], K = d.getProperty(c), et = d.quickSetter(c, g.a, le), un(c, ce, Zt), Ft = Nr(c)), Q) {
                gt = Nt(Q) ? In(Q, zn) : zn, a = Br("scroller-start", p, w, g, gt, 0), He = Br("scroller-end", p, w, g, gt, 0, a), Tt = a["offset" + g.op.d2];
                var ar = Be(At(w, "content") || w);
                Xe = this.markerStart = Br("start", p, ar, g, gt, Tt, 0, y), Ne = this.markerEnd = Br("end", p, ar, g, gt, Tt, 0, y), y && (Jt = d.quickSetter([Xe, Ne], g.a, le)), !Ee && !(ft.length && At(w, "fixedMarkers") === !0) && (ki(ie ? L : w), d.set([a, He], {
                    force3D: !0
                }), Mr = d.quickSetter(a, g.a, le), Kt = d.quickSetter(He, g.a, le))
            }
            if (y) {
                var S = y.vars.onUpdate,
                    m = y.vars.onUpdateParams;
                y.eventCallback("onUpdate", function() {
                    s.update(0, 0, 1), S && S.apply(y, m || [])
                })
            }
            if (s.previous = function() {
                    return T[T.indexOf(s) - 1]
                }, s.next = function() {
                    return T[T.indexOf(s) + 1]
                }, s.revert = function(f, b) {
                    if (!b) return s.kill(!0);
                    var _ = f !== !1 || !s.enabled,
                        C = Ce;
                    _ !== s.isReverted && (_ && (nt = Math.max(ee(), s.scroll.rec || 0), me = s.progress, zt = r && r.progress()), Xe && [Xe, Ne, a, He].forEach(function(fe) {
                        return fe.style.display = _ ? "none" : "block"
                    }), _ && (Ce = s, s.update(_)), c && (!qe || !s.isActive) && (_ ? Di(c, ce, ht) : un(c, ce, Qe(c), te)), _ || s.update(_), Ce = C, s.isReverted = _)
                }, s.refresh = function(f, b, _, C) {
                    if (!((Ce || !s.enabled) && !b)) {
                        if (c && f && je) {
                            de(o, "scrollEnd", pi);
                            return
                        }!Fe && oe && oe(s), Ce = s, Me.tween && !_ && (Me.tween.kill(), Me.tween = 0), D && D.pause(), $ && r && (r.revert({
                            kill: !1
                        }).invalidate(), r.getChildren && r.getChildren(!0, !0, !1).forEach(function(Pt) {
                            return Pt.vars.immediateRender && Pt.render(0, !0, !0)
                        })), s.isReverted || s.revert(!0, !0), s._subPinOffset = !1;
                        var fe = Yt(),
                            A = bt(),
                            Z = y ? y.duration() : ct(w, g),
                            we = U <= .01 || !U,
                            V = 0,
                            H = C || 0,
                            z = Nt(_) ? _.end : t.end,
                            it = t.endTrigger || h,
                            G = Nt(_) ? _.start : t.start || (t.start === 0 || !h ? 0 : c ? "0 0" : "0 100%"),
                            We = s.pinnedContainer = t.pinnedContainer && Be(t.pinnedContainer, s),
                            st = h && Math.max(0, T.indexOf(s)) || 0,
                            he = st,
                            _e, ye, Xt, Dr, be, se, lt, rn, Mn, ur, at, cr, Rr;
                        for (Q && Nt(_) && (cr = d.getProperty(a, g.p), Rr = d.getProperty(He, g.p)); he-- > 0;) se = T[he], se.end || se.refresh(0, 1) || (Ce = s), lt = se.pin, lt && (lt === h || lt === c || lt === We) && !se.isReverted && (ur || (ur = []), ur.unshift(se), se.revert(!0, !0)), se !== T[he] && (st--, he--);
                        for (ke(G) && (G = G(s)), G = On(G, "start", s), O = Hn(G, h, fe, g, ee(), Xe, a, s, A, j, Ee, Z, y, s._startClamp && "_startClamp") || (c ? -.001 : 0), ke(z) && (z = z(s)), $e(z) && !z.indexOf("+=") && (~z.indexOf(" ") ? z = ($e(G) ? G.split(" ")[0] : "") + z : (V = $r(z.substr(2), fe), z = $e(G) ? G : (y ? d.utils.mapRange(0, y.duration(), y.scrollTrigger.start, y.scrollTrigger.end, O) : O) + V, it = h)), z = On(z, "end", s), q = Math.max(O, Hn(z || (it ? "100% 0" : Z), it, fe, g, ee() + V, Ne, He, s, A, j, Ee, Z, y, s._endClamp && "_endClamp")) || -.001, V = 0, he = st; he--;) se = T[he], lt = se.pin, lt && se.start - se._pinPush <= O && !y && se.end > 0 && (_e = se.end - (s._startClamp ? Math.max(0, se.start) : se.start), (lt === h && se.start - se._pinPush < O || lt === We) && isNaN(G) && (V += _e * (1 - se.progress)), lt === c && (H += _e));
                        if (O += V, q += V, s._startClamp && (s._startClamp += V), s._endClamp && !Fe && (s._endClamp = q || -.001, q = Math.min(q, ct(w, g))), U = q - O || (O -= .01) && .001, we && (me = d.utils.clamp(0, 1, d.utils.normalize(O, q, nt))), s._pinPush = H, Xe && V && (_e = {}, _e[g.a] = "+=" + V, We && (_e[g.p] = "-=" + ee()), d.set([Xe, Ne], _e)), c && !(vn && s.end >= ct(w, g))) _e = Qe(c), Dr = g === ae, Xt = ee(), Ze = parseFloat(K(g.a)) + H, !Z && q > 1 && (at = (ie ? B.scrollingElement || Ue : w).style, at = {
                            style: at,
                            value: at["overflow" + g.a.toUpperCase()]
                        }, ie && Qe(L)["overflow" + g.a.toUpperCase()] !== "scroll" && (at.style["overflow" + g.a.toUpperCase()] = "scroll")), un(c, ce, _e), Ft = Nr(c), ye = xt(c, !0), rn = Ee && Ot(w, Dr ? Le : ae)(), v ? (te = [v + g.os2, U + H + le], te.t = ce, he = v === re ? jr(c, g) + U + H : 0, he && (te.push(g.d, he + le), ce.style.flexBasis !== "auto" && (ce.style.flexBasis = he + le)), or(te), We && T.forEach(function(Pt) {
                            Pt.pin === We && Pt.vars.pinSpacing !== !1 && (Pt._subPinOffset = !0)
                        }), Ee && ee(nt)) : (he = jr(c, g), he && ce.style.flexBasis !== "auto" && (ce.style.flexBasis = he + le)), Ee && (be = {
                            top: ye.top + (Dr ? Xt - O : rn) + le,
                            left: ye.left + (Dr ? rn : Xt - O) + le,
                            boxSizing: "border-box",
                            position: "fixed"
                        }, be[Wt] = be["max" + sr] = Math.ceil(ye.width) + le, be[Gt] = be["max" + Tn] = Math.ceil(ye.height) + le, be[Je] = be[Je + Sr] = be[Je + br] = be[Je + kr] = be[Je + Cr] = "0", be[re] = _e[re], be[re + Sr] = _e[re + Sr], be[re + br] = _e[re + br], be[re + kr] = _e[re + kr], be[re + Cr] = _e[re + Cr], kt = Ai(ht, be, qe), Fe && ee(0)), r ? (Mn = r._initted, nn(1), r.render(r.duration(), !0, !0), _t = K(g.a) - Ze + U + H, vt = Math.abs(U - _t) > 1, Ee && vt && kt.splice(kt.length - 2, 2), r.render(0, !0, !0), Mn || r.invalidate(!0), r.parent || r.totalTime(r.totalTime()), nn(0)) : _t = U, at && (at.value ? at.style["overflow" + g.a.toUpperCase()] = at.value : at.style.removeProperty("overflow-" + g.a));
                        else if (h && ee() && !y)
                            for (ye = h.parentNode; ye && ye !== L;) ye._pinOffset && (O -= ye._pinOffset, q -= ye._pinOffset), ye = ye.parentNode;
                        ur && ur.forEach(function(Pt) {
                            return Pt.revert(!1, !0)
                        }), s.start = O, s.end = q, De = ze = Fe ? nt : ee(), !y && !Fe && (De < nt && ee(nt), s.scroll.rec = 0), s.revert(!1, !0), dt = Se(), rt && (Ke = -1, rt.restart(!0)), Ce = 0, r && ue && (r._initted || zt) && r.progress() !== zt && r.progress(zt || 0, !0).render(r.time(), !0, !0), (we || me !== s.progress || y || $ || r && !r._initted) && (r && !ue && (r._initted || me || r.vars.immediateRender !== !1) && r.totalProgress(y && O < -.001 && !me ? d.utils.normalize(O, q, 0) : me, !0), s.progress = we || (De - O) / U === me ? 0 : me), c && v && (ce._pinOffset = Math.round(s.progress * _t)), D && D.invalidate(), isNaN(cr) || (cr -= d.getProperty(a, g.p), Rr -= d.getProperty(He, g.p), Hr(a, g, cr), Hr(Xe, g, cr - (C || 0)), Hr(He, g, Rr), Hr(Ne, g, Rr - (C || 0))), we && !Fe && s.update(), Y && !Fe && !St && (St = !0, Y(s), St = !1)
                    }
                }, s.getVelocity = function() {
                    return (ee() - ze) / (Se() - dr) * 1e3 || 0
                }, s.endAnimation = function() {
                    pr(s.callbackAnimation), r && (D ? D.progress(1) : r.paused() ? ue || pr(r, s.direction < 0, 1) : pr(r, r.reversed()))
                }, s.labelToScroll = function(f) {
                    return r && r.labels && (O || s.refresh() || O) + r.labels[f] / r.duration() * U || 0
                }, s.getTrailing = function(f) {
                    var b = T.indexOf(s),
                        _ = s.direction > 0 ? T.slice(0, b).reverse() : T.slice(b + 1);
                    return ($e(f) ? _.filter(function(C) {
                        return C.vars.preventOverlaps === f
                    }) : _).filter(function(C) {
                        return s.direction > 0 ? C.end <= O : C.start >= q
                    })
                }, s.update = function(f, b, _) {
                    if (!(y && !_ && !f)) {
                        var C = Fe === !0 ? nt : s.scroll(),
                            fe = f ? 0 : (C - O) / U,
                            A = fe < 0 ? 0 : fe > 1 ? 1 : fe || 0,
                            Z = s.progress,
                            we, V, H, z, it, G, We, st;
                        if (b && (ze = De, De = y ? ee() : C, k && (Lt = Et, Et = r && !ue ? r.totalProgress() : A)), X && c && !Ce && !Fr && je && (!A && O < C + (C - ze) / (Se() - dr) * X ? A = 1e-4 : A === 1 && q > C + (C - ze) / (Se() - dr) * X && (A = .9999)), A !== Z && s.enabled) {
                            if (we = s.isActive = !!A && A < 1, V = !!Z && Z < 1, G = we !== V, it = G || !!A != !!Z, s.direction = A > Z ? 1 : -1, s.progress = A, it && !Ce && (H = A && !Z ? 0 : A === 1 ? 1 : Z === 1 ? 2 : 3, ue && (z = !G && I[H + 1] !== "none" && I[H + 1] || I[H], st = r && (z === "complete" || z === "reset" || z in r))), Ie && (G || st) && (st || M || !r) && (ke(Ie) ? Ie(s) : s.getTrailing(Ie).forEach(function(Xt) {
                                    return Xt.endAnimation()
                                })), ue || (D && !Ce && !Fr ? (D._dp._time - D._start !== D._time && D.render(D._dp._time - D._start), D.resetTo ? D.resetTo("totalProgress", A, r._tTime / r._tDur) : (D.vars.totalProgress = A, D.invalidate().restart())) : r && r.totalProgress(A, !!(Ce && (dt || f)))), c) {
                                if (f && v && (ce.style[v + g.os2] = lr), !Ee) et(hr(Ze + _t * A));
                                else if (it) {
                                    if (We = !f && A > Z && q + 1 > C && C + 1 >= ct(w, g), qe)
                                        if (!f && (we || We)) {
                                            var he = xt(c, !0),
                                                _e = C - O;
                                            Wn(c, L, he.top + (g === ae ? _e : 0) + le, he.left + (g === ae ? 0 : _e) + le)
                                        } else Wn(c, ce);
                                    or(we || We ? kt : Ft), vt && A < 1 && we || et(Ze + (A === 1 && !We ? _t : 0))
                                }
                            }
                            k && !Me.tween && !Ce && !Fr && rt.restart(!0), l && (G || ge && A && (A < 1 || !on)) && Er(l.targets).forEach(function(Xt) {
                                return Xt.classList[we || ge ? "add" : "remove"](l.className)
                            }), u && !ue && !f && u(s), it && !Ce ? (ue && (st && (z === "complete" ? r.pause().totalProgress(1) : z === "reset" ? r.restart(!0).pause() : z === "restart" ? r.restart(!0) : r[z]()), u && u(s)), (G || !on) && (x && G && ln(s, x), Pe[H] && ln(s, Pe[H]), ge && (A === 1 ? s.kill(!1, 1) : Pe[H] = 0), G || (H = A === 1 ? 1 : 3, Pe[H] && ln(s, Pe[H]))), Te && !we && Math.abs(s.getVelocity()) > (_r(Te) ? Te : 2500) && (pr(s.callbackAnimation), D ? D.progress(1) : pr(r, z === "reverse" ? 1 : !A, 1))) : ue && u && !Ce && u(s)
                        }
                        if (Kt) {
                            var ye = y ? C / y.duration() * (y._caScrollDist || 0) : C;
                            Mr(ye + (a._isFlipped ? 1 : 0)), Kt(ye)
                        }
                        Jt && Jt(-C / y.duration() * (y._caScrollDist || 0))
                    }
                }, s.enable = function(f, b) {
                    s.enabled || (s.enabled = !0, de(w, "resize", vr), ie || de(w, "scroll", jt), oe && de(o, "refreshInit", oe), f !== !1 && (s.progress = me = 0, De = ze = Ke = ee()), b !== !1 && s.refresh())
                }, s.getTween = function(f) {
                    return f && Me ? Me.tween : D
                }, s.setPositions = function(f, b, _, C) {
                    if (y) {
                        var fe = y.scrollTrigger,
                            A = y.duration(),
                            Z = fe.end - fe.start;
                        f = fe.start + Z * f / A, b = fe.start + Z * b / A
                    }
                    s.refresh(!1, !1, {
                        start: Yn(f, _ && !!s._startClamp),
                        end: Yn(b, _ && !!s._endClamp)
                    }, C), s.update()
                }, s.adjustPinSpacing = function(f) {
                    if (te && f) {
                        var b = te.indexOf(g.d) + 1;
                        te[b] = parseFloat(te[b]) + f + le, te[1] = parseFloat(te[1]) + f + le, or(te)
                    }
                }, s.disable = function(f, b) {
                    if (s.enabled && (f !== !1 && s.revert(!0, !0), s.enabled = s.isActive = !1, b || D && D.pause(), nt = 0, xe && (xe.uncache = 1), oe && pe(o, "refreshInit", oe), rt && (rt.pause(), Me.tween && Me.tween.kill() && (Me.tween = 0)), !ie)) {
                        for (var _ = T.length; _--;)
                            if (T[_].scroller === w && T[_] !== s) return;
                        pe(w, "resize", vr), ie || pe(w, "scroll", jt)
                    }
                }, s.kill = function(f, b) {
                    s.disable(f, b), D && !b && D.kill(), p && delete mn[p];
                    var _ = T.indexOf(s);
                    _ >= 0 && T.splice(_, 1), _ === Ye && Vr > 0 && Ye--, _ = 0, T.forEach(function(C) {
                        return C.scroller === s.scroller && (_ = 1)
                    }), _ || Fe || (s.scroll.rec = 0), r && (r.scrollTrigger = null, f && r.revert({
                        kill: !1
                    }), b || r.kill()), Xe && [Xe, Ne, a, He].forEach(function(C) {
                        return C.parentNode && C.parentNode.removeChild(C)
                    }), Tr === s && (Tr = 0), c && (xe && (xe.uncache = 1), _ = 0, T.forEach(function(C) {
                        return C.pin === c && _++
                    }), _ || (xe.spacer = 0)), t.onKill && t.onKill(s)
                }, T.push(s), s.enable(!1, !1), mt && mt(s), r && r.add && !U) {
                var F = s.update;
                s.update = function() {
                    s.update = F, P.cache++, O || q || s.refresh()
                }, d.delayedCall(.01, s.update), U = .01, O = q = 0
            } else s.refresh();
            c && Mi()
        }, o.register = function(t) {
            return er || (d = t || si(), oi() && window.document && o.enable(), er = gr), er
        }, o.defaults = function(t) {
            if (t)
                for (var r in t) Xr[r] = t[r];
            return Xr
        }, o.disable = function(t, r) {
            gr = 0, T.forEach(function(u) {
                return u[r ? "kill" : "disable"](t)
            }), pe(E, "wheel", jt), pe(B, "scroll", jt), clearInterval(Yr), pe(B, "touchcancel", ut), pe(L, "touchstart", ut), Ir(pe, B, "pointerdown,touchstart,mousedown", Fn), Ir(pe, B, "pointerup,touchend,mouseup", Ln), Jr.kill(), Lr(pe);
            for (var i = 0; i < P.length; i += 3) zr(pe, P[i], P[i + 1]), zr(pe, P[i], P[i + 2])
        }, o.enable = function() {
            if (E = window, B = document, Ue = B.documentElement, L = B.body, d && (Er = d.utils.toArray, yr = d.utils.clamp, _n = d.core.context || ut, nn = d.core.suppressOverwrites || ut, bn = E.history.scrollRestoration || "auto", xn = E.pageYOffset || 0, d.core.globals("ScrollTrigger", o), L)) {
                gr = 1, ir = document.createElement("div"), ir.style.height = "100vh", ir.style.position = "absolute", hi(), bi(), J.register(d), o.isTouch = J.isTouch, Mt = J.isTouch && /(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent), hn = J.isTouch === 1, de(E, "wheel", jt), yn = [E, B, Ue, L], d.matchMedia ? (o.matchMedia = function(x) {
                    var Y = d.matchMedia(),
                        M;
                    for (M in x) Y.add(M, x[M]);
                    return Y
                }, d.addEventListener("matchMediaInit", function() {
                    return Pn()
                }), d.addEventListener("matchMediaRevert", function() {
                    return di()
                }), d.addEventListener("matchMedia", function() {
                    Ht(0, 1), qt("matchMedia")
                }), d.matchMedia().add("(orientation: portrait)", function() {
                    return an(), an
                })) : console.warn("Requires GSAP 3.11.0 or later"), an(), de(B, "scroll", jt);
                var t = L.hasAttribute("style"),
                    r = L.style,
                    i = r.borderTopStyle,
                    u = d.core.Animation.prototype,
                    l, p;
                for (u.revert || Object.defineProperty(u, "revert", {
                        value: function() {
                            return this.time(-.01, !0)
                        }
                    }), r.borderTopStyle = "solid", l = xt(L), ae.m = Math.round(l.top + ae.sc()) || 0, Le.m = Math.round(l.left + Le.sc()) || 0, i ? r.borderTopStyle = i : r.removeProperty("border-top-style"), t || (L.setAttribute("style", ""), L.removeAttribute("style")), Yr = setInterval(Xn, 250), d.delayedCall(.5, function() {
                        return Fr = 0
                    }), de(B, "touchcancel", ut), de(L, "touchstart", ut), Ir(de, B, "pointerdown,touchstart,mousedown", Fn), Ir(de, B, "pointerup,touchend,mouseup", Ln), gn = d.utils.checkPrefix("transform"), qr.push(gn), er = Se(), Jr = d.delayedCall(.2, Ht).pause(), tr = [B, "visibilitychange", function() {
                        var x = E.innerWidth,
                            Y = E.innerHeight;
                        B.hidden ? (Rn = x, An = Y) : (Rn !== x || An !== Y) && vr()
                    }, B, "DOMContentLoaded", Ht, E, "load", Ht, E, "resize", vr], Lr(de), T.forEach(function(x) {
                        return x.enable(0, 1)
                    }), p = 0; p < P.length; p += 3) zr(pe, P[p], P[p + 1]), zr(pe, P[p], P[p + 2])
            }
        }, o.config = function(t) {
            "limitCallbacks" in t && (on = !!t.limitCallbacks);
            var r = t.syncInterval;
            r && clearInterval(Yr) || (Yr = r) && setInterval(Xn, r), "ignoreMobileResize" in t && (hn = o.isTouch === 1 && t.ignoreMobileResize), "autoRefreshEvents" in t && (Lr(pe) || Lr(de, t.autoRefreshEvents || "none"), ri = (t.autoRefreshEvents + "").indexOf("resize") === -1)
        }, o.scrollerProxy = function(t, r) {
            var i = Be(t),
                u = P.indexOf(i),
                l = Ut(i);
            ~u && P.splice(u, l ? 6 : 2), r && (l ? ft.unshift(E, r, L, r, Ue, r) : ft.unshift(i, r))
        }, o.clearMatchMedia = function(t) {
            T.forEach(function(r) {
                return r._ctx && r._ctx.query === t && r._ctx.kill(!0, !0)
            })
        }, o.isInViewport = function(t, r, i) {
            var u = ($e(t) ? Be(t) : t).getBoundingClientRect(),
                l = u[i ? Wt : Gt] * r || 0;
            return i ? u.right - l > 0 && u.left + l < E.innerWidth : u.bottom - l > 0 && u.top + l < E.innerHeight
        }, o.positionInViewport = function(t, r, i) {
            $e(t) && (t = Be(t));
            var u = t.getBoundingClientRect(),
                l = u[i ? Wt : Gt],
                p = r == null ? l / 2 : r in en ? en[r] * l : ~r.indexOf("%") ? parseFloat(r) * l / 100 : parseFloat(r) || 0;
            return i ? (u.left + p) / E.innerWidth : (u.top + p) / E.innerHeight
        }, o.killAll = function(t) {
            if (T.slice(0).forEach(function(i) {
                    return i.vars.id !== "ScrollSmoother" && i.kill()
                }), t !== !0) {
                var r = Vt.killAll || [];
                Vt = {}, r.forEach(function(i) {
                    return i()
                })
            }
        }, o
    })();
R.version = "3.13.0";
R.saveStyles = function(o) {
    return o ? Er(o).forEach(function(e) {
        if (e && e.style) {
            var n = Ge.indexOf(e);
            n >= 0 && Ge.splice(n, 5), Ge.push(e, e.style.cssText, e.getBBox && e.getAttribute("transform"), d.core.getCache(e), _n())
        }
    }) : Ge
};
R.revert = function(o, e) {
    return Pn(!o, e)
};
R.create = function(o, e) {
    return new R(o, e)
};
R.refresh = function(o) {
    return o ? vr(!0) : (er || R.register()) && Ht(!0)
};
R.update = function(o) {
    return ++P.cache && yt(o === !0 ? 2 : 0)
};
R.clearScrollMemory = gi;
R.maxScroll = function(o, e) {
    return ct(o, e ? Le : ae)
};
R.getScrollFunc = function(o, e) {
    return Ot(Be(o), e ? Le : ae)
};
R.getById = function(o) {
    return mn[o]
};
R.getAll = function() {
    return T.filter(function(o) {
        return o.vars.id !== "ScrollSmoother"
    })
};
R.isScrolling = function() {
    return !!je
};
R.snapDirectional = En;
R.addEventListener = function(o, e) {
    var n = Vt[o] || (Vt[o] = []);
    ~n.indexOf(e) || n.push(e)
};
R.removeEventListener = function(o, e) {
    var n = Vt[o],
        t = n && n.indexOf(e);
    t >= 0 && n.splice(t, 1)
};
R.batch = function(o, e) {
    var n = [],
        t = {},
        r = e.interval || .016,
        i = e.batchMax || 1e9,
        u = function(x, Y) {
            var M = [],
                h = [],
                c = d.delayedCall(r, function() {
                    Y(M, h), M = [], h = []
                }).pause();
            return function(v) {
                M.length || c.restart(!0), M.push(v.trigger), h.push(v), i <= M.length && c.progress(1)
            }
        },
        l;
    for (l in e) t[l] = l.substr(0, 2) === "on" && ke(e[l]) && l !== "onRefreshInit" ? u(l, e[l]) : e[l];
    return ke(i) && (i = i(), de(R, "refresh", function() {
        return i = e.batchMax()
    })), Er(o).forEach(function(p) {
        var x = {};
        for (l in t) x[l] = t[l];
        x.trigger = p, n.push(R.create(x))
    }), n
};
var $n = function(e, n, t, r) {
        return n > r ? e(r) : n < 0 && e(0), t > r ? (r - n) / (t - n) : t < 0 ? n / (n - t) : 1
    },
    cn = function o(e, n) {
        n === !0 ? e.style.removeProperty("touch-action") : e.style.touchAction = n === !0 ? "auto" : n ? "pan-" + n + (J.isTouch ? " pinch-zoom" : "") : "none", e === Ue && o(L, n)
    },
    Wr = {
        auto: 1,
        scroll: 1
    },
    Yi = function(e) {
        var n = e.event,
            t = e.target,
            r = e.axis,
            i = (n.changedTouches ? n.changedTouches[0] : n).target,
            u = i._gsap || d.core.getCache(i),
            l = Se(),
            p;
        if (!u._isScrollT || l - u._isScrollT > 2e3) {
            for (; i && i !== L && (i.scrollHeight <= i.clientHeight && i.scrollWidth <= i.clientWidth || !(Wr[(p = Qe(i)).overflowY] || Wr[p.overflowX]));) i = i.parentNode;
            u._isScroll = i && i !== t && !Ut(i) && (Wr[(p = Qe(i)).overflowY] || Wr[p.overflowX]), u._isScrollT = l
        }(u._isScroll || r === "x") && (n.stopPropagation(), n._gsapAllow = !0)
    },
    vi = function(e, n, t, r) {
        return J.create({
            target: e,
            capture: !0,
            debounce: !1,
            lockAxis: !0,
            type: n,
            onWheel: r = r && Yi,
            onPress: r,
            onDrag: r,
            onScroll: r,
            onEnable: function() {
                return t && de(B, J.eventTypes[0], Vn, !1, !0)
            },
            onDisable: function() {
                return pe(B, J.eventTypes[0], Vn, !0)
            }
        })
    },
    Fi = /(input|label|select|textarea)/i,
    Un, Vn = function(e) {
        var n = Fi.test(e.target.tagName);
        (n || Un) && (e._gsapAllow = !0, Un = n)
    },
    Li = function(e) {
        Nt(e) || (e = {}), e.preventDefault = e.isNormalizer = e.allowClicks = !0, e.type || (e.type = "wheel,touch"), e.debounce = !!e.debounce, e.id = e.id || "normalizer";
        var n = e,
            t = n.normalizeScrollX,
            r = n.momentum,
            i = n.allowNestedScroll,
            u = n.onRelease,
            l, p, x = Be(e.target) || Ue,
            Y = d.core.globals().ScrollSmoother,
            M = Y && Y.get(),
            h = Mt && (e.content && Be(e.content) || M && e.content !== !1 && !M.smooth() && M.content()),
            c = Ot(x, ae),
            v = Ot(x, Le),
            $ = 1,
            X = (J.isTouch && E.visualViewport ? E.visualViewport.scale * E.visualViewport.width : E.outerWidth) / E.innerWidth,
            ne = 0,
            W = ke(r) ? function() {
                return r(l)
            } : function() {
                return r || 2.8
            },
            ge, k, qe = vi(x, e.type, !0, i),
            N = function() {
                return k = !1
            },
            y = ut,
            Te = ut,
            Ie = function() {
                p = ct(x, ae), Te = yr(Mt ? 1 : 0, p), t && (y = yr(0, ct(x, Le))), ge = $t
            },
            g = function() {
                h._gsap.y = hr(parseFloat(h._gsap.y) + c.offset) + "px", h.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + parseFloat(h._gsap.y) + ", 0, 1)", c.offset = c.cacheID = 0
            },
            ue = function() {
                if (k) {
                    requestAnimationFrame(N);
                    var Q = hr(l.deltaY / 2),
                        j = Te(c.v - Q);
                    if (h && j !== c.v + c.offset) {
                        c.offset = j - c.v;
                        var s = hr((parseFloat(h && h._gsap.y) || 0) - c.offset);
                        h.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + s + ", 0, 1)", h._gsap.y = s + "px", c.cacheID = P.cache, yt()
                    }
                    return !0
                }
                c.offset && g(), k = !0
            },
            w, pt, ie, Ee, Pe = function() {
                Ie(), w.isActive() && w.vars.scrollY > p && (c() > p ? w.progress(1) && c(p) : w.resetTo("scrollY", p))
            };
        return h && d.set(h, {
            y: "+=0"
        }), e.ignoreCheck = function(I) {
            return Mt && I.type === "touchmove" && ue() || $ > 1.05 && I.type !== "touchstart" || l.isGesturing || I.touches && I.touches.length > 1
        }, e.onPress = function() {
            k = !1;
            var I = $;
            $ = hr((E.visualViewport && E.visualViewport.scale || 1) / X), w.pause(), I !== $ && cn(x, $ > 1.01 ? !0 : t ? !1 : "x"), pt = v(), ie = c(), Ie(), ge = $t
        }, e.onRelease = e.onGestureStart = function(I, Q) {
            if (c.offset && g(), !Q) Ee.restart(!0);
            else {
                P.cache++;
                var j = W(),
                    s, oe;
                t && (s = v(), oe = s + j * .05 * -I.velocityX / .227, j *= $n(v, s, oe, ct(x, Le)), w.vars.scrollX = y(oe)), s = c(), oe = s + j * .05 * -I.velocityY / .227, j *= $n(c, s, oe, ct(x, ae)), w.vars.scrollY = Te(oe), w.invalidate().duration(j).play(.01), (Mt && w.vars.scrollY >= p || s >= p - 1) && d.to({}, {
                    onUpdate: Pe,
                    duration: j
                })
            }
            u && u(I)
        }, e.onWheel = function() {
            w._ts && w.pause(), Se() - ne > 1e3 && (ge = 0, ne = Se())
        }, e.onChange = function(I, Q, j, s, oe) {
            if ($t !== ge && Ie(), Q && t && v(y(s[2] === Q ? pt + (I.startX - I.x) : v() + Q - s[1])), j) {
                c.offset && g();
                var Yt = oe[2] === j,
                    bt = Yt ? ie + I.startY - I.y : c() + j - oe[1],
                    Ke = Te(bt);
                Yt && bt !== Ke && (ie += Ke - bt), c(Ke)
            }(j || Q) && yt()
        }, e.onEnable = function() {
            cn(x, t ? !1 : "x"), R.addEventListener("refresh", Pe), de(E, "resize", Pe), c.smooth && (c.target.style.scrollBehavior = "auto", c.smooth = v.smooth = !1), qe.enable()
        }, e.onDisable = function() {
            cn(x, !0), pe(E, "resize", Pe), R.removeEventListener("refresh", Pe), qe.kill()
        }, e.lockAxis = e.lockAxis !== !1, l = new J(e), l.iOS = Mt, Mt && !c() && c(1), Mt && d.ticker.add(ut), Ee = l._dc, w = d.to(l, {
            ease: "power4",
            paused: !0,
            inherit: !1,
            scrollX: t ? "+=0.1" : "+=0",
            scrollY: "+=0.1",
            modifiers: {
                scrollY: _i(c, c(), function() {
                    return w.pause()
                })
            },
            onUpdate: yt,
            onComplete: Ee.vars.onComplete
        }), l
    };
R.sort = function(o) {
    if (ke(o)) return T.sort(o);
    var e = E.pageYOffset || 0;
    return R.getAll().forEach(function(n) {
        return n._sortY = n.trigger ? e + n.trigger.getBoundingClientRect().top : n.start + E.innerHeight
    }), T.sort(o || function(n, t) {
        return (n.vars.refreshPriority || 0) * -1e6 + (n.vars.containerAnimation ? 1e6 : n._sortY) - ((t.vars.containerAnimation ? 1e6 : t._sortY) + (t.vars.refreshPriority || 0) * -1e6)
    })
};
R.observe = function(o) {
    return new J(o)
};
R.normalizeScroll = function(o) {
    if (typeof o > "u") return Oe;
    if (o === !0 && Oe) return Oe.enable();
    if (o === !1) {
        Oe && Oe.kill(), Oe = o;
        return
    }
    var e = o instanceof J ? o : Li(o);
    return Oe && Oe.target === e.target && Oe.kill(), Ut(e.target) && (Oe = e), e
};
R.core = {
    _getVelocityProp: dn,
    _inputObserver: vi,
    _scrollers: P,
    _proxies: ft,
    bridge: {
        ss: function() {
            je || qt("scrollStart"), je = Se()
        },
        ref: function() {
            return Ce
        }
    }
};
si() && d.registerPlugin(R);
export {
    R as S
};